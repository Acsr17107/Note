package com.cookandroid.project13_1;

import android.Manifest;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listViewMP3;
    Button btnPlay, btnPause, btnStop;
    TextView tvMP3;
    ProgressBar pdMP3;

    ArrayList<String> mp3List = new ArrayList<>();
    String selectedMP3;
    String mp3Path = Environment.getExternalStorageDirectory().getPath() + "/";
    MediaPlayer mPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        setTitle("간단 MP3 플레이어 (개선)");

        // 권한 요청
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                100);

        // 인셋 처리
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // 위젯 연결
        listViewMP3 = findViewById(R.id.listViewMP3);
        btnPlay = findViewById(R.id.btnPlay);
        btnPause = findViewById(R.id.btnPause);
        btnStop = findViewById(R.id.btnStop);
        tvMP3 = findViewById(R.id.tvMP3);
        pdMP3 = findViewById(R.id.pdMP3);

        // MP3 파일 목록 불러오기
        File[] listFiles = new File(mp3Path).listFiles();
        if (listFiles != null) {
            for (File file : listFiles) {
                String fileName = file.getName();
                String extName = fileName.substring(fileName.length() - 3);
                if (extName.equals("mp3")) {
                    mp3List.add(fileName);
                }
            }
        }

        // 어댑터 설정
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_single_choice, mp3List);
        listViewMP3.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        listViewMP3.setAdapter(adapter);
        listViewMP3.setItemChecked(0, true);

        if (!mp3List.isEmpty()) {
            selectedMP3 = mp3List.get(0);
        }

        listViewMP3.setOnItemClickListener((parent, view, position, id) -> {
            selectedMP3 = mp3List.get(position);
        });

        // ▶ 듣기 버튼 (처음부터 재생)
        btnPlay.setOnClickListener(v -> {
            try {
                if (mPlayer != null) {
                    mPlayer.stop();
                    mPlayer.reset();
                    mPlayer.release();
                    mPlayer = null;
                }

                mPlayer = new MediaPlayer();
                mPlayer.setDataSource(mp3Path + selectedMP3);
                mPlayer.prepare();
                mPlayer.start();

                btnPlay.setClickable(false);
                btnPause.setClickable(true);
                btnStop.setClickable(true);
                pdMP3.setVisibility(View.VISIBLE);
                tvMP3.setText("실행중인 음악 : " + selectedMP3);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        // Ⅱ 일시정지 버튼
        btnPause.setOnClickListener(v -> {
            if (mPlayer != null && mPlayer.isPlaying()) {
                mPlayer.pause();
                tvMP3.setText("일시정지됨 : " + selectedMP3);
            }
        });

        // ■ 정지 버튼
        btnStop.setOnClickListener(v -> {
            if (mPlayer != null) {
                mPlayer.stop();
                mPlayer.reset();
                mPlayer.release();
                mPlayer = null;
            }

            btnPlay.setClickable(true);
            btnPause.setClickable(false);
            btnStop.setClickable(false);
            pdMP3.setVisibility(View.INVISIBLE);
            tvMP3.setText("실행중인 음악 : ");
        });

        // 앱 실행 시 일시정지/중지 버튼 비활성화
        btnPause.setClickable(false);
        btnStop.setClickable(false);
    }
}
